#include "arduino_secrets.h"

#include <SoftwareSerial.h>
#include <DFRobotDFPlayerMini.h>

SoftwareSerial mp3Serial(10, 11);   // RX, TX
DFRobotDFPlayerMini player;

void setup() {
  Serial.begin(9600);

  // Wait for the Serial Monitor to connect (Nano R4)
  while (!Serial) {
    ;
  }

  delay(2000);

  Serial.println("Starting DFPlayer test...");

  mp3Serial.begin(9600);

  if (!player.begin(mp3Serial)) {
    Serial.println("ERROR: DFPlayer not found!");
    while (1) {
      delay(1000);
    }
  }

  Serial.println("DFPlayer found!");

  int fileCount = player.readFileCounts();
  Serial.print("Files on SD card: ");
  Serial.println(fileCount);

  Serial.println("Setting volume to 30...");
  player.volume(30);

  delay(1000);

  Serial.println("Playing track 1...");
  player.play(1);
}

void loop() {
  static unsigned long lastPrint = 0;

  if (millis() - lastPrint >= 2000) {
    lastPrint = millis();

    Serial.print("Files on SD card: ");
    Serial.println(player.readFileCounts());

    Serial.print("Current volume: ");
    Serial.println(player.readVolume());
  }
}