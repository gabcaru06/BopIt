#include "arduino_secrets.h"

#include <Wire.h>

void setup() {
  Serial.begin(9600);

  Serial.println("Starting in 10 seconds...");

  for (int i = 10; i > 0; i--) {
    Serial.print("Seconds left: ");
    Serial.println(i);
    delay(1000);
  }

  Wire.begin();

  Serial.println("Scanning I2C...");

  int devices = 0;

  for (byte address = 1; address < 127; address++) {
    Wire.beginTransmission(address);

    if (Wire.endTransmission() == 0) {
      Serial.print("Found device at 0x");
      Serial.println(address, HEX);
      devices++;
    }
  }

  if (devices == 0) {
    Serial.println("No I2C devices found");
  }
}

void loop() {
}